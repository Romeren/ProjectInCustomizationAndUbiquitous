package org.xtext.sdu.iotvizualizerlanguage.generator;

import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class ModelGenerator {
  public ModelGenerator(final Resource resource) {
  }
}
