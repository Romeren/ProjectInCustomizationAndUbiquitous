from __future__ import absolute_import

import os

from celery import Celery

# Set the default Django settings module for the celery app
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'webserver.settings')

from django.conf import settings

app = Celery('webserver')

# Using a string here means the worker will not have to
# prickle the object when using windows
app.config_from_object('django.conf:settings')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)

# List Size 5
uri_list = {
	"lol": "http://10.123.3.12:8079/api/data/uuid/bec6ad6b-753a-548d-bb8c-4e03f4d67b2e?endtime=1463909610000&limit=100"
	"temperature": "http://10.123.3.12:8079/api/query"
	"foobar": "http://10.123.3.12:8079/api/data/uuid/b4cb304d-1425-5165-b83d-f3dc985858a6?endtime=2463909610000&limit=100"
	"co2": "http://10.123.3.12:8079/api/query"
	"pir": "http://10.123.3.12:8079/api/query"
}
import datatime
import celery

@celery.decorators.periodic_task(run_every=datetime.timedelta(minutes=5))
def fetchFromUrl(): 
	print("Running Task")
	
