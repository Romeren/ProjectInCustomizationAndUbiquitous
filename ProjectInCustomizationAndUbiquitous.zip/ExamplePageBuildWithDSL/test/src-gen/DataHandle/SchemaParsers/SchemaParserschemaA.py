from DataHandle.SchemaParsers.AbstractSchemaParser import AbstractSchemaParser 
from DataHandle.Selectors.Selectorx import Selectorx

class SchemaParserschemaA(AbstractSchemaParser):
	def __init__(self):
		self.selectors = []
		self.selectors.append(Selectorx())		
		self.contentType = 'JSON'
