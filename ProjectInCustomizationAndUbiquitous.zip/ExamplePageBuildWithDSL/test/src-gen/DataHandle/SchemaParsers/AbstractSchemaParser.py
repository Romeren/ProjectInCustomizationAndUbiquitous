class AbstractSchemaParser():
	def __init__(self):		
		self.selectors = []
