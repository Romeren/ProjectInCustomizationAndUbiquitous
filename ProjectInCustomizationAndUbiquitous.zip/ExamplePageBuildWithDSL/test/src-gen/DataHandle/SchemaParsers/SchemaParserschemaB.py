from DataHandle.SchemaParsers.AbstractSchemaParser import AbstractSchemaParser 
from DataHandle.Selectors.Selectorx20508a1 import Selectorx20508a1
from DataHandle.Selectors.Selectorx205101 import Selectorx205101
from DataHandle.Selectors.Selectorx205111 import Selectorx205111
from DataHandle.Selectors.Selectorx20601b1 import Selectorx20601b1
from DataHandle.Selectors.Selectorx206031 import Selectorx206031
from DataHandle.Selectors.Selectorx20604b1 import Selectorx20604b1
from DataHandle.Selectors.Selectorx225081 import Selectorx225081
from DataHandle.Selectors.Selectorx225101 import Selectorx225101
from DataHandle.Selectors.Selectorx225111 import Selectorx225111
from DataHandle.Selectors.Selectorx22601b1 import Selectorx22601b1
from DataHandle.Selectors.Selectorx226031 import Selectorx226031
from DataHandle.Selectors.Selectorx226041 import Selectorx226041

class SchemaParserschemaB(AbstractSchemaParser):
	def __init__(self):
		self.selectors = []
		self.selectors.append(Selectorx20508a1())		
		self.selectors.append(Selectorx205101())		
		self.selectors.append(Selectorx205111())		
		self.selectors.append(Selectorx20601b1())		
		self.selectors.append(Selectorx206031())		
		self.selectors.append(Selectorx20604b1())		
		self.selectors.append(Selectorx225081())		
		self.selectors.append(Selectorx225101())		
		self.selectors.append(Selectorx225111())		
		self.selectors.append(Selectorx22601b1())		
		self.selectors.append(Selectorx226031())		
		self.selectors.append(Selectorx226041())		
		self.contentType = 'JSON'
