import requests
import time
import datetime
import numpy as np

class AbstractEndpoint():
	def fetchData(self, url):
		if self.json == "":
			response = requests.get(url)
			return response
		else:
			response = requests.post(url, self.json)
			return response
	
	def getJson(self, request):
		return request.json()

	def getText(self, request):
		return request.text

	def getJsonElement(self, json, selectorStep):
		return json[selectorStep]
		
	def getTextElement(self, text, selectorStep):
		return text

	def getElement(self, data, selector, type):
		for selc in selector.steps:
			if type == 'JSON':
				data = self.getJsonElement(data,selc)
			else:
				data = self.getTextElement(data,selc)
		return data

	def getData(self):
		if self.data:
			return self.data
		result = {}
		
		response = self.fetchData(self.url)
		
		if self.schemaParser.contentType is 'JSON':
			response = self.getJson(response)
		else: #TODO: HANDLE CSV AND XML
			response = self.getText(response) 
		
		for selector in self.schemaParser.selectors:
			result[selector.name] = np.array(self.getElement(response, selector, self.schemaParser.contentType))
		
		self.data = result
		return result
