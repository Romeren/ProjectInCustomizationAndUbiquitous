from DataHandle.EndPoints.AbstractEndpoint import AbstractEndpoint
import DataHandle.SchemaParsers.SchemaParserschemaA  as s
import datetime
import time

class EndPointlol(AbstractEndpoint):
	def __init__(self):
		self.schemaParser = s.SchemaParserschemaA()
		self.url = "http://10.123.3.12:8079/api/data/uuid/bec6ad6b-753a-548d-bb8c-4e03f4d67b2e?endtime=1463909610000&limit=100"
		self.data = None
		self.json = ""
		
