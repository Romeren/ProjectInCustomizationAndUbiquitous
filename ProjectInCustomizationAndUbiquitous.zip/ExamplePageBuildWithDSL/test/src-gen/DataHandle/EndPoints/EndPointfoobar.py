from DataHandle.EndPoints.AbstractEndpoint import AbstractEndpoint
import DataHandle.SchemaParsers.SchemaParserschemaA  as s
import datetime
import time

class EndPointfoobar(AbstractEndpoint):
	def __init__(self):
		self.schemaParser = s.SchemaParserschemaA()
		self.url = "http://10.123.3.12:8079/api/data/uuid/b4cb304d-1425-5165-b83d-f3dc985858a6?endtime=2463909610000&limit=100"
		self.data = None
		self.json = ""
		
