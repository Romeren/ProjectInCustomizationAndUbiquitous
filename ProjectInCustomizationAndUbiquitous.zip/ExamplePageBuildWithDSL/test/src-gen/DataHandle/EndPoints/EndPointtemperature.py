from DataHandle.EndPoints.AbstractEndpoint import AbstractEndpoint
import DataHandle.SchemaParsers.SchemaParserschemaB  as s
import datetime
import time

class EndPointtemperature(AbstractEndpoint):
	def __init__(self):
		self.schemaParser = s.SchemaParserschemaB()
		self.url = "http://10.123.3.12:8079/api/query"
		self.data = None
		self.json = "select data in('" + (datetime.datetime.fromtimestamp(time.time()) - datetime.timedelta(1)).strftime('%m/%d/%Y') + "', '" + datetime.datetime.fromtimestamp(time.time()).strftime('%m/%d/%Y') + "') where Path like '/1 - Ground/%/Temperature'"
		
