import numpy as np
import DataHandle.EndPoints.EndPointlol as e_lol
import DataHandle.EndPoints.EndPointtemperature as e_temperature
import DataHandle.EndPoints.EndPointfoobar as e_foobar
import DataHandle.EndPoints.EndPointco2 as e_co2
import DataHandle.EndPoints.EndPointpir as e_pir

class DatasourceController():
	def datasource_a(self):
		endpoint_lol = e_lol.EndPointlol()
	
		result = {}
		input_x = np.array(endpoint_lol.getData()['x'])
		input_n = np.array(endpoint_lol.getData()['x'])

		input_x[::, 1] = input_x[::, 1]+input_x[::, 1]*2+9+input_n[::, 1]
		result['dimension_x'] = input_x
		input_x = np.array(endpoint_lol.getData()['x'])
		input_n = np.array(endpoint_lol.getData()['x'])

		input_x[::, 1] = input_x[::, 1]+input_x[::, 1]*3+input_n[::, 1]
		result['dimension_z'] = input_x
		return result
		
		
	def datasource_c(self):
		endpoint_foobar = e_foobar.EndPointfoobar()
	
		result = {}
		input_z = np.array(endpoint_foobar.getData()['x'])

		input_z[::, 1] = input_z[::, 1]*3/9
		result['dimension_g'] = input_z
		return result
		
		
	def datasource_temperatureRaw(self):
		endpoint_temperature = e_temperature.EndPointtemperature()
	
		result = {}
		input_x = np.array(endpoint_temperature.getData()['x20508a1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20508a1'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x205101'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x205101'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x205111'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x205111'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x20601b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20601b1'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x206031'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x206031'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x20604b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20604b1'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x225081'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225081'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x225101'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225101'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x225111'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225111'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x22601b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x22601b1'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x226031'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x226031'] = input_x
		input_x = np.array(endpoint_temperature.getData()['x226041'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x226041'] = input_x
		return result
		
		
	def datasource_co2Raw(self):
		endpoint_co2 = e_co2.EndPointco2()
	
		result = {}
		input_x = np.array(endpoint_co2.getData()['x20508a1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20508a1'] = input_x
		input_x = np.array(endpoint_co2.getData()['x205101'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x205101'] = input_x
		input_x = np.array(endpoint_co2.getData()['x205111'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x205111'] = input_x
		input_x = np.array(endpoint_co2.getData()['x20601b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20601b1'] = input_x
		input_x = np.array(endpoint_co2.getData()['x206031'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x206031'] = input_x
		input_x = np.array(endpoint_co2.getData()['x20604b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20604b1'] = input_x
		input_x = np.array(endpoint_co2.getData()['x225081'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225081'] = input_x
		input_x = np.array(endpoint_co2.getData()['x225101'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225101'] = input_x
		input_x = np.array(endpoint_co2.getData()['x225111'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225111'] = input_x
		input_x = np.array(endpoint_co2.getData()['x22601b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x22601b1'] = input_x
		input_x = np.array(endpoint_co2.getData()['x226031'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x226031'] = input_x
		input_x = np.array(endpoint_co2.getData()['x226041'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x226041'] = input_x
		return result
		
		
	def datasource_pirRaw(self):
		endpoint_pir = e_pir.EndPointpir()
	
		result = {}
		input_x = np.array(endpoint_pir.getData()['x20508a1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20508a1'] = input_x
		input_x = np.array(endpoint_pir.getData()['x205101'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x205101'] = input_x
		input_x = np.array(endpoint_pir.getData()['x205111'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x205111'] = input_x
		input_x = np.array(endpoint_pir.getData()['x20601b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20601b1'] = input_x
		input_x = np.array(endpoint_pir.getData()['x206031'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x206031'] = input_x
		input_x = np.array(endpoint_pir.getData()['x20604b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x20604b1'] = input_x
		input_x = np.array(endpoint_pir.getData()['x225081'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225081'] = input_x
		input_x = np.array(endpoint_pir.getData()['x225101'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225101'] = input_x
		input_x = np.array(endpoint_pir.getData()['x225111'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x225111'] = input_x
		input_x = np.array(endpoint_pir.getData()['x22601b1'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x22601b1'] = input_x
		input_x = np.array(endpoint_pir.getData()['x226031'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x226031'] = input_x
		input_x = np.array(endpoint_pir.getData()['x226041'])

		input_x[::, 1] = input_x[::, 1]
		result['dimension_x226041'] = input_x
		return result
		
		
