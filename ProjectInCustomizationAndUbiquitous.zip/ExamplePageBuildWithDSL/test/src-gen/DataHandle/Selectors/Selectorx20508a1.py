from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx20508a1(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(0)
		self.steps.append("Readings")
		self.name = "x20508a1"
		
