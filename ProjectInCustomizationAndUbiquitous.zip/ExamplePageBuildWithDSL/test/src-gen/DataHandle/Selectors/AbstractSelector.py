class AbstractSelector():
	def __init__(self):
		self.steps = []
		self.name = None
