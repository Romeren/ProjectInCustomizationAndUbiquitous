from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx225111(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(8)
		self.steps.append("Readings")
		self.name = "x225111"
		
