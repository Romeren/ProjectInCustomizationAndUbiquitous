from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx20601b1(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(3)
		self.steps.append("Readings")
		self.name = "x20601b1"
		
