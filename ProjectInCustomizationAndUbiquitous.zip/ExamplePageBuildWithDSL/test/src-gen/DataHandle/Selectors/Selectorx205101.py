from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx205101(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(1)
		self.steps.append("Readings")
		self.name = "x205101"
		
