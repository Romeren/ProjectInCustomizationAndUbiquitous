from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx20604b1(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(5)
		self.steps.append("Readings")
		self.name = "x20604b1"
		
