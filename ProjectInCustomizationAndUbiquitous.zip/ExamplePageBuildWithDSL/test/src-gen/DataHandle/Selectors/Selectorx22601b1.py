from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx22601b1(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(9)
		self.steps.append("Readings")
		self.name = "x22601b1"
		
