from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx225101(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(7)
		self.steps.append("Readings")
		self.name = "x225101"
		
