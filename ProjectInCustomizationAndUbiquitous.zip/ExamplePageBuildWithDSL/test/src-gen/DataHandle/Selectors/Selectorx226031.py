from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx226031(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(10)
		self.steps.append("Readings")
		self.name = "x226031"
		
