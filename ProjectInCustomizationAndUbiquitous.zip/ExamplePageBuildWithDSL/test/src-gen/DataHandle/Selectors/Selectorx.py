from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(0)
		self.steps.append("Readings")
		self.name = "x"
		
