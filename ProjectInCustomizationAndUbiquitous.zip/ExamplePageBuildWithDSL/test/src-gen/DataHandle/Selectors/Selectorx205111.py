from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx205111(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(2)
		self.steps.append("Readings")
		self.name = "x205111"
		
