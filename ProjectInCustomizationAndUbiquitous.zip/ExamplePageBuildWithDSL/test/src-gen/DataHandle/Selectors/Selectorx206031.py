from DataHandle.Selectors.AbstractSelector import AbstractSelector
class Selectorx206031(AbstractSelector):
	def __init__(self):
		self.steps = []
		self.steps.append(4)
		self.steps.append("Readings")
		self.name = "x206031"
		
