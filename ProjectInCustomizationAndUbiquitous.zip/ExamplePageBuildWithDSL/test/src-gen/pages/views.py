from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.template import Context
from DataHandle.Datasources.Controller import DatasourceController

import json
import numpy as np
class NumpyToJson(json.JSONEncoder):
	def default(self, obj):
		if isinstance(obj, np.ndarray):
			return obj.tolist()
		return json.JSONEncoder.default(self, obj)

converter = NumpyToJson()

def index(request):
	template = loader.get_template('index.html');
	
	contentMap = {}

	context = Context(contentMap)
	return HttpResponse(template.render(context))

def pageOne(request):
	template = loader.get_template('pageOne.html');
	
	contentMap = {}

	context = Context(contentMap)
	return HttpResponse(template.render(context))

def Temperatures(request):
	template = loader.get_template('Temperatures.html');
	
	contentMap = {}
	contentMap['graph_data_tempGraph'] = {key : converter.default(value) for key, value in DatasourceController().datasource_temperatureRaw().items()}
	contentMap['graph_data_co2Graph'] = {key : converter.default(value) for key, value in DatasourceController().datasource_co2Raw().items()}

	context = Context(contentMap)
	return HttpResponse(template.render(context))

def CO2(request):
	template = loader.get_template('CO2.html');
	
	contentMap = {}
	contentMap['graph_data_co2Graph'] = {key : converter.default(value) for key, value in DatasourceController().datasource_co2Raw().items()}

	context = Context(contentMap)
	return HttpResponse(template.render(context))

def PIR(request):
	template = loader.get_template('PIR.html');
	
	contentMap = {}
	contentMap['graph_data_pirGraph'] = {key : converter.default(value) for key, value in DatasourceController().datasource_pirRaw().items()}

	context = Context(contentMap)
	return HttpResponse(template.render(context))


